# Site event Halloween first mobile
This was a website I made for a halloween event. I prioritized developing it for mobile first.
From the UI/UX to the HTML and Css and Code the site will have was produced by me. 
The mix between my academic background in marketing with my studies in design and programming gave me the capacity to be able to start something great. It took work, but that's what we live for. 
